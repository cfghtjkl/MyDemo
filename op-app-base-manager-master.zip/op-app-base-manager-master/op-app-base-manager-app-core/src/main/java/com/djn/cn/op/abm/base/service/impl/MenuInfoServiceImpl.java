package com.djn.cn.op.abm.base.service.impl;


import com.djn.cn.op.abm.base.entity.MenuInfo;
import com.djn.cn.op.abm.base.service.IMenuInfoService;
import org.springframework.stereotype.Service;


@Service
public class MenuInfoServiceImpl extends  BaseServiceImpl<MenuInfo> implements IMenuInfoService {
}

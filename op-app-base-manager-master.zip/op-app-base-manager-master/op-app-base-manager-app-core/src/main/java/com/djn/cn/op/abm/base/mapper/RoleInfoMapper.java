package com.djn.cn.op.abm.base.mapper;

import com.djn.cn.op.abm.base.entity.RoleInfo;

public interface RoleInfoMapper extends MyMapper<RoleInfo> {
}
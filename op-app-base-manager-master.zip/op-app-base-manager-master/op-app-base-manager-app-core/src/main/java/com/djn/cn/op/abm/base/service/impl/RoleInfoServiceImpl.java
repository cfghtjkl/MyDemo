package com.djn.cn.op.abm.base.service.impl;

import com.djn.cn.op.abm.base.entity.RoleInfo;
import com.djn.cn.op.abm.base.service.IRoleInfoService;
import org.springframework.stereotype.Service;

@Service
public class RoleInfoServiceImpl extends BaseServiceImpl<RoleInfo> implements IRoleInfoService {

}

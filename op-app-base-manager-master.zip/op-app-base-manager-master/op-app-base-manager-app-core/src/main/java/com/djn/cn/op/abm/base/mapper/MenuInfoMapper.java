package com.djn.cn.op.abm.base.mapper;

import com.djn.cn.op.abm.base.entity.MenuInfo;

public interface MenuInfoMapper extends MyMapper<MenuInfo> {
}
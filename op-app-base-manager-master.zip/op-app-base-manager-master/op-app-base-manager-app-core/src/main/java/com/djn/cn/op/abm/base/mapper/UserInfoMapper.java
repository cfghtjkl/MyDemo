package com.djn.cn.op.abm.base.mapper;

import com.djn.cn.op.abm.base.entity.UserInfo;

public interface UserInfoMapper extends MyMapper<UserInfo> {
}